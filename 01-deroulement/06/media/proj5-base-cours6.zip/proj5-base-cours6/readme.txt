# Projet démo d'animation de balle - Cours 6

Concepts explorés : interpolation (position, opacité), acceleration et ralentissement, squash & stretch, exportation.